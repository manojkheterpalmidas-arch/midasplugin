/* UI only: setup guidance, view navigation and explicit result freshness.
   Numerical analysis remains in concurrent.js, combos.js and run.js. */
(function (root) {
  "use strict";
  var state = null, signature = "", resultSignature = null, startedSignature = null;
  var active = "setup", hasResult = false, invalidated = false;
  function $(id) { return document.getElementById(id); }
  function put(id, value) { var el = $(id); if (el && el.textContent !== value) el.textContent = value; }
  function selected(id) { var el = $(id); return el && el.selectedIndex >= 0 ? el.options[el.selectedIndex].textContent : ""; }
  function mark(id, done) {
    var el = $(id); el.classList.toggle("done", !!done);
    el.querySelector(".check-mark").textContent = done ? "✓" : "○";
  }
  function show(view, focus) {
    if (view === "results" && !hasResult) return;
    active = view;
    $("setup-view").hidden = view !== "setup";
    $("results-view").hidden = view !== "results";
    ["setup", "results"].forEach(function (name) {
      $("nav-" + name).classList.toggle("active", view === name);
      $("nav-" + name).setAttribute("aria-pressed", String(view === name));
    });
    if (view === "results") root.dispatchEvent(new Event("resize"));
    if (focus) {
      $("nav-" + view).focus({ preventScroll: true });
      document.querySelector(".workspace-nav").scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }
  function update(s) {
    state = s;
    var set = root.CfElements.parseSet($("in-set").value);
    var key = root.CfElements.parseSet(s.keyText || "");
    var setOk = !set.errors.length && set.members.length > 0;
    var keyOk = key.members.length === 1 && !key.errors.length &&
      set.members.some(function (m) { return m.key === key.members[0].key; });
    var criterion = (document.querySelector("input[name=criterion]:checked") || {}).value || "max";
    var criterionText = { max: "maximum", min: "minimum", absmax: "largest absolute" }[criterion];
    var effect = selected("in-component");
    var keyLabel = key.members.length === 1 && !key.errors.length ? key.members[0].key : "—";
    var names = s.selection || [];
    var ready = s.connected && !s.loading && names.length && setOk && keyOk && !!effect;
    signature = JSON.stringify({ set: $("in-set").value, key: s.keyText, effect: $("in-component").value,
      criterion: criterion, units: [$("in-force").value, $("in-dist").value], cases: names, stages: s.stages });
    put("summary-cases", names.length ? names.slice(0, 3).join(", ") + (names.length > 3 ? " + " + (names.length - 3) + " more" : "") : "None selected");
    put("summary-items", setOk ? set.members.length + (set.members.length === 1 ? " item" : " items") : "—");
    put("summary-key", keyLabel);
    put("summary-effect", effect || "—");
    put("question-summary", names.length && keyOk && effect
      ? "Find the " + criterionText + " " + effect + " at " + keyLabel + ". Report " + set.members.length + " items at that same condition across " + (names.length === 1 ? "the selected case or combination." : names.length + " selected cases / combinations.")
      : "Choose a combination, add your items, and define the governing component.");
    put("criterion-help", criterion === "min" ? "Minimum finds the lowest signed value (e.g. −120 rather than +80)." : criterion === "absmax" ? "Absolute maximum compares magnitudes and keeps the original sign (e.g. −120 rather than +80)." : "Maximum finds the highest signed value (e.g. +80 rather than −120).");
    mark("ready-model", s.connected && !s.loading); mark("ready-cases", names.length); mark("ready-set", setOk); mark("ready-key", keyOk && !!effect);
    $("in-set").setAttribute("aria-invalid", String(!!set.errors.length));
    $("in-key-elem").setAttribute("aria-invalid", String(!!$("in-key-elem").value.trim() && !keyOk));
    put("run-hint", s.running ? "Finding the governing condition…" : s.loading ? "Loading your model…" : !s.connected ? "Connect to CIVIL NX to get started." : !names.length ? "Step 1: select a case or combination." : !setOk ? "Step 2: enter a valid set of items." : !keyOk ? "Step 3: choose a reference item within the set." : !effect ? "Step 3: select a governing component." : "Ready · " + set.members.length + " items · " + names.length + " selected");
    $("btn-run").disabled = !ready || s.running;
    $("btn-run").setAttribute("aria-busy", String(!!s.running));
    $("stale-notice").hidden = !hasResult || (!invalidated && resultSignature === signature);
    $("setup-view").inert = !!(s.running || s.loading);
    $("setup-view").setAttribute("aria-busy", String(!!(s.running || s.loading)));
    ["btn-connect", "btn-connect-dev", "btn-probe"].forEach(function (id) { $(id).disabled = !!(s.running || s.loading); });
  }
  function start() { startedSignature = signature; if (hasResult) { invalidated = true; $("stale-notice").hidden = false; } }
  function complete(rows) {
    hasResult = true; invalidated = false; resultSignature = startedSignature;
    $("nav-results").disabled = false;
    put("results-count", String(rows));
    if (state) update(state);
    show("results", true);
  }
  function invalidate() { if (hasResult) { invalidated = true; $("stale-notice").hidden = false; } }
  function init() {
    $("nav-setup").addEventListener("click", function () { show("setup", false); });
    $("nav-results").addEventListener("click", function () { show("results", false); });
    $("btn-edit-setup").addEventListener("click", function () { show("setup", true); });
    $("btn-help").addEventListener("click", function () {
      var el = $("how-it-works"); el.hidden = !el.hidden;
      $("btn-help").setAttribute("aria-expanded", String(!el.hidden));
    });
  }
  root.CfUI = { update: update, start: start, complete: complete, invalidate: invalidate, show: show };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})(typeof globalThis !== "undefined" ? globalThis : this);
