# Concurrent Force Reporter v1.0.0 — validation

v1.0.0 is the first Marketplace release. Its code is the package previously
carried internally as 1.6.1; only the version strings differ.

## Checked offline

An isolated jsdom harness loaded the delivered HTML and JavaScript with a
deterministic fixture model in place of the API. No live service or user model
was used. The real model, combination, concurrency, analysis, chart and report
modules handled that fixture. All 12 integration check groups passed without
uncaught DOM errors. JavaScript syntax, local asset paths and release metadata
were also checked.

Checks covered:

- First-open defaults and disabled run before connection.
- Preservation of every control ID; no duplicate IDs.
- Help disclosure and light/dark theme switching.
- Model and combination population, blocked moving-load combinations,
  individual/all constituent expansion and optional API labels.
- Search, selected-only filtering and summary retention when selections are hidden.
- Item-set validation, reference-in-set gating and structure-group replacement.
- Busy state and connection-control locking during a run.
- Governing My = 225 at reference element 12 for the fixture combination;
  eight concurrent rows, generated chart elements and CSV.
- Automatic Results view, return to Setup and previous-results notice after edits.
- Output-position filtering from eight rows to four, with corresponding CSV.
- Failed result retrieval and failed refresh, including control recovery.
- Original REQ_WND_MOVE and REQ_EXIT host messages.

## Checked in a browser

A local HTTP preview of this exact folder was loaded at the requested window
size of 1200 × 740.

- Header, claim, connection panel and view tabs stay on single lines.
- The workspace keeps its two columns: setup column plus the 300 px summary rail.
- Setup cards 1–3, the combination table, the structure-group picker, the three
  governing-criterion tiles and the output-units row render without clipping or
  horizontal overflow.
- The sticky run footer stays pinned with the primary button at full size.
- Document height is 1764 px, so the setup view scrolls vertically.

The window is 1200 × 740 because on a 1920 × 1080 screen at 125 % Windows
scaling the desktop is 1536 × 826 logical pixels; 1200 × 740 fits with room for
the host chrome and stays above the 1000 px breakpoint where the two-column
layout collapses.

## What still needs checking in CIVIL NX

Rendering inside the CIVIL NX host itself, and CSV download behaviour there,
have not been checked.

Construction stages remain unverified — no reference model available has any.

A parser issue carried from development remains in the numerical code:
whitespace-only force cells can be interpreted as zero.

## Verified on a live model during development

1736 plates, 580 elastic links, 78 combinations, all static. 96+ driver items
were each resolved independently and re-read; all passed self-validation, worst
|reconstructed − NX| ≈ 1.06e-8. 14 near-ties occurred in the first 72 items.

The moving-load refusal path is implemented but was not exercised by that model,
and is verified only against the offline fixture.
